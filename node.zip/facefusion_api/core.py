from concurrent.futures import ThreadPoolExecutor
from functools import partial
from io import BytesIO
from typing import Tuple, Optional, List, Dict, Any

import torch
import numpy as np
from comfy.comfy_types import IO
from comfy_api.input_impl.video_types import VideoFromComponents
from comfy_api.util import VideoComponents
from comfy_api_nodes.util import bytesio_to_image_tensor, tensor_to_bytesio
from httpx import Client as HttpClient, Headers
from httpx_retries import Retry, RetryTransport
from torch import Tensor

from .types import FaceSwapperModel, InputTypes
from .utils import tensor_to_cv2, cv2_to_tensor, get_average_embedding, implode_pixel_boost, explode_pixel_boost
from .face_detector import detect_faces, select_faces
from .local_swapper import swap_faces_local


class SwapFaceImage:
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'source_images': (IO.IMAGE,),  # Changed to plural to support batches
				'target_image': (IO.IMAGE,),
				'api_token':
				(
					'STRING',
					{
						'default': '-1'
					}
				),
				'face_swapper_model':
				(
					[
						'hyperswap_1a_256',
						'hyperswap_1b_256',
						'hyperswap_1c_256'
					],
					{
						'default': 'hyperswap_1c_256'
					}
				)
			}
		}

	RETURN_TYPES = (IO.IMAGE,)
	FUNCTION = 'process'
	CATEGORY = 'FaceFusion API'

	@staticmethod
	def process(source_images : Tensor, target_image : Tensor, api_token : str, face_swapper_model : FaceSwapperModel) -> Tuple[Tensor]:
		# Smart batch processing - handle any input format
		# Use first source image (or average multiple sources in future)
		if source_images.dim() == 4 and source_images.shape[0] > 1:
			source_image = source_images[0:1]
		else:
			source_image = source_images
		
		# Check if target is a batch
		if target_image.dim() == 4 and target_image.shape[0] > 1:
			# Process each target image in the batch
			print(f"[SwapFaceImage] Processing batch of {target_image.shape[0]} images")
			output_images = []
			for i in range(target_image.shape[0]):
				single_target = target_image[i:i+1]
				swapped = SwapFaceImage.swap_face(source_image, single_target, api_token, face_swapper_model, '512x512', 0.3)
				output_images.append(swapped)
			# Stack all results back into batch
			output_tensor = torch.cat(output_images, dim=0)
		else:
			# Single image processing
			output_tensor = SwapFaceImage.swap_face(source_image, target_image, api_token, face_swapper_model, '512x512', 0.3)
		
		return (output_tensor,)

	@staticmethod
	def swap_face(source_tensor : Tensor, target_tensor : Tensor, api_token : str, face_swapper_model : FaceSwapperModel, pixel_boost: str = '512x512', face_mask_blur: float = 0.3) -> Tensor:
		# Check if using local inference
		if api_token == '-1':
			# print("[SwapFaceImage] Using local inference")
			try:
				# Convert tensors to OpenCV format
				source_cv2 = tensor_to_cv2(source_tensor)
				target_cv2 = tensor_to_cv2(target_tensor)
				
				# Perform local face swap
				result_cv2 = swap_faces_local(
					source_image=source_cv2,
					target_image=target_cv2,
					model_name=face_swapper_model,
					pixel_boost=pixel_boost,
					face_mask_blur=face_mask_blur,
					face_selector_mode='one',
					face_position=0,
					score_threshold=0.3
				)
				
				# Convert back to tensor
				result_tensor = cv2_to_tensor(result_cv2)
				return result_tensor
			except Exception as e:
				print(f"[SwapFaceImage] Local inference error: {e}")
				import traceback
				traceback.print_exc()
				return target_tensor
		
		# Use API
		# print("[SwapFaceImage] Using API inference")
		source_buffer : BytesIO = tensor_to_bytesio(source_tensor, mime_type = 'image/webp')
		target_buffer : BytesIO = tensor_to_bytesio(target_tensor, mime_type = 'image/webp')

		url = 'https://api.facefusion.io/inferences/swap-face'
		files =\
		{
			'source': ('source.webp', source_buffer, 'image/webp'),
			'target': ('target.webp', target_buffer, 'image/webp'),
		}
		data =\
		{
			'face_swapper_model': face_swapper_model,
		}
		headers = Headers()
		retry = Retry(total = 5, backoff_factor = 1)
		transport = RetryTransport(retry = retry)

		if api_token and api_token != '-1':
			headers['X-Token'] = api_token

		with HttpClient(transport = transport) as http_client:
			response = http_client.post(url, headers = headers, files = files, data = data)

			if response.status_code == 200:
				output_buffer = BytesIO(response.content)
				output_tensor = bytesio_to_image_tensor(output_buffer)
				return output_tensor

		return target_tensor


class SwapFaceVideo:
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'source_images': (IO.IMAGE,),  # Changed to plural to support batches
				'target_video': (IO.VIDEO,),
				'api_token':
				(
					'STRING',
					{
						'default': '-1'
					}
				),
				'face_swapper_model':
				(
					[
						'hyperswap_1a_256',
						'hyperswap_1b_256',
						'hyperswap_1c_256'
					],
					{
						'default': 'hyperswap_1a_256'
					}
				),
				'max_workers':
				(
					'INT',
					{
						'default': 16,
						'min': 1,
						'max': 32
					}
				)
			}
		}

	RETURN_TYPES = (IO.VIDEO,)
	FUNCTION = 'process'
	CATEGORY = 'FaceFusion API'

	@staticmethod
	def process(source_images : Tensor, target_video : VideoFromComponents, api_token : str, face_swapper_model : FaceSwapperModel, max_workers : int) -> Tuple[VideoFromComponents]:
		# Handle multiple source images by taking the first one
		if source_images.dim() == 4 and source_images.shape[0] > 1:
			source_image = source_images[0:1]
		else:
			source_image = source_images
			
		video_components = target_video.get_components()
		output_tensors = []

		swap_face = partial(
			SwapFaceImage.swap_face,
			source_image,
			api_token = api_token,
			face_swapper_model = face_swapper_model
		)

		with ThreadPoolExecutor(max_workers = max_workers) as executor:
			for temp_tensor in executor.map(swap_face, video_components.images):
				temp_tensor = temp_tensor.squeeze(0)[..., :3]
				output_tensors.append(temp_tensor)

		output_video_components = VideoComponents(
			images = torch.stack(output_tensors),
			audio = video_components.audio,
			frame_rate = video_components.frame_rate
		)

		output_video = VideoFromComponents(output_video_components)
		return (output_video,)


class FaceDetectorNode:
	"""Node for detecting and selecting faces from an image."""
	
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'image': (IO.IMAGE,),
				'face_detector_model':
				(
					['scrfd', 'retinaface', 'yolo_face', 'yunet', 'many'],
					{
						'default': 'scrfd'
					}
				),
				'face_selector_mode':
				(
					['one', 'many', 'reference'],
					{
						'default': 'one'
					}
				),
				'face_position':
				(
					'INT',
					{
						'default': 0,
						'min': 0,
						'max': 100,
						'step': 1
					}
				),
			'sort_order':
			(
				['large-small', 'small-large', 'left-right', 'right-left', 'top-bottom', 'bottom-top', 'best-worst', 'worst-best'],
				{
					'default': 'large-small'
				}
			),
			'score_threshold':
			(
				'FLOAT',
				{
					'default': 0.3,
					'min': 0.0,
					'max': 1.0,
					'step': 0.05
				}
			)
		},
		'optional':
		{
			'reference_image': (IO.IMAGE,),
				'reference_face_distance':
				(
					'FLOAT',
					{
						'default': 0.6,
						'min': 0.0,
						'max': 1.0,
						'step': 0.05
					}
				)
			}
		}
	
	RETURN_TYPES = ('FACE_DATA',)
	RETURN_NAMES = ('face_data',)
	FUNCTION = 'detect'
	CATEGORY = 'FaceFusion'
	
	def detect(
		self,
		image: Tensor,
		face_detector_model: str,
		face_selector_mode: str,
		face_position: int,
		sort_order: str,
		score_threshold: float,
		reference_image: Optional[Tensor] = None,
		reference_face_distance: float = 0.6
	) -> Tuple[Dict]:
		"""Detect and select faces from an image - smart batch handling."""
		try:
			# print(f"[FaceDetectorNode] Using detector model: {face_detector_model}")
			
			# Check if input is a batch
			if image.dim() == 4 and image.shape[0] > 1:
				print(f"[FaceDetectorNode] Processing batch of {image.shape[0]} images - using first image")
				# For face detection, use first image in batch
				# (detecting faces from multiple images doesn't make sense in this context)
				single_image = image[0:1]
			else:
				single_image = image
			
			# Convert tensor to OpenCV format
			cv2_image = tensor_to_cv2(single_image)
			
			# Note: face_detector_model selection will be implemented when multi-model support is added
			# Currently only SCRFD is implemented
			if face_detector_model != 'scrfd':
				print(f"[FaceDetectorNode] Warning: Only 'scrfd' is currently implemented. Using SCRFD.")
			
			# Detect faces with sorting
			faces = detect_faces(cv2_image, score_threshold, sort_order)
			
			if not faces:
				print("No faces detected in image")
				# Return serializable data
				return ({'faces': [], 'image': single_image, 'num_faces': 0},)
			
			# Select faces based on mode
			selected_faces = []
			
			if face_selector_mode == 'one':
				if face_position < len(faces):
					selected_faces = [faces[face_position]]
			elif face_selector_mode == 'many':
				selected_faces = faces
			elif face_selector_mode == 'reference' and reference_image is not None:
				# Get reference face
				ref_single = reference_image[0:1] if reference_image.dim() == 4 and reference_image.shape[0] > 1 else reference_image
				ref_cv2_image = tensor_to_cv2(ref_single)
				ref_faces = detect_faces(ref_cv2_image, score_threshold, 'large-small')
				
				if ref_faces:
					# Get first reference face
					ref_face = ref_faces[0]
					# Find matching faces
					from .utils import find_matching_faces
					selected_faces = find_matching_faces(ref_face, faces, reference_face_distance)
			
			# print(f"Detected {len(faces)} faces, selected {len(selected_faces)} faces")
			
			# Convert numpy arrays to serializable format and store cv2_image separately
			serializable_faces = []
			for face in selected_faces:
				serializable_face = {
					'bbox': face['bbox'].tolist() if hasattr(face['bbox'], 'tolist') else face['bbox'],
					'landmarks': face['landmarks'].tolist() if hasattr(face['landmarks'], 'tolist') else face['landmarks'],
					'score': float(face['score']),
					'area': float(face['area'])
				}
				if 'embedding' in face and face['embedding'] is not None:
					serializable_face['embedding'] = face['embedding'].tolist()
				if 'distance' in face:
					serializable_face['distance'] = float(face['distance'])
				serializable_faces.append(serializable_face)
			
			# Store cv2_image for internal use but don't serialize it
			face_data = {
				'faces': serializable_faces,
				'image': single_image,
				'num_faces': len(selected_faces),
				'_cv2_image': cv2_image  # Internal use only
			}
			
			return (face_data,)
		except Exception as e:
			print(f"Error in face detection: {e}")
			import traceback
			traceback.print_exc()
			return ({'faces': [], 'image': image, 'num_faces': 0},)


class AdvancedSwapFaceImage:
	"""Advanced face swapping node with face selection options."""
	
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'source_images': (IO.IMAGE,),
				'target_image': (IO.IMAGE,),
				'api_token':
				(
					'STRING',
					{
						'default': '-1'
					}
				),
				'face_swapper_model':
				(
					[
						'hyperswap_1a_256',
						'hyperswap_1b_256',
						'hyperswap_1c_256'
					],
					{
						'default': 'hyperswap_1c_256'
					}
				),
				'pixel_boost':
				(
					['256x256', '512x512', '768x768', '1024x1024'],
					{
						'default': '512x512'
					}
				),
				'face_occluder_model':
				(
					['xseg_1', 'xseg_2', 'xseg_3', 'many'],
					{
						'default': 'xseg_1'
					}
				),
				'face_parser_model':
				(
					['bisenet_resnet_18', 'bisenet_resnet_34'],
					{
						'default': 'bisenet_resnet_34'
					}
				),
				'face_mask_blur':
				(
					'FLOAT',
					{
						'default': 0.3,
						'min': 0.0,
						'max': 1.0,
						'step': 0.05
					}
				),
				'face_selector_mode':
				(
					['one', 'many', 'reference'],
					{
						'default': 'one'
					}
				),
			'face_position':
			(
				'INT',
				{
					'default': 0,
					'min': 0,
					'max': 100
				}
			),
			'score_threshold':
			(
				'FLOAT',
				{
					'default': 0.3,
					'min': 0.0,
					'max': 1.0,
					'step': 0.05
				}
			)
		},
		'optional':
		{
			'reference_image': (IO.IMAGE,),
			'reference_face_distance':
			(
				'FLOAT',
				{
					'default': 0.6,
					'min': 0.0,
						'max': 1.0,
						'step': 0.05
					}
				)
			}
		}
	
	RETURN_TYPES = (IO.IMAGE,)
	FUNCTION = 'process'
	CATEGORY = 'FaceFusion'
	
	def process(
		self,
		source_images: Tensor,
		target_image: Tensor,
		api_token: str,
		face_swapper_model: FaceSwapperModel,
		pixel_boost: str,
		face_occluder_model: str,
		face_parser_model: str,
		face_mask_blur: float,
		face_selector_mode: str,
		face_position: int,
		score_threshold: float,
		reference_image: Optional[Tensor] = None,
		reference_face_distance: float = 0.6
	) -> Tuple[Tensor]:
		"""Process face swapping with advanced selection - smart batch handling."""
		# Note: pixel_boost, face_occluder, and face_parser are used with local inference
		# print(f"[AdvancedSwapFaceImage] Settings: pixel_boost={pixel_boost}, occluder={face_occluder_model}, parser={face_parser_model}")
		
		# Handle multiple source images - use first one
		if source_images.dim() == 4 and source_images.shape[0] > 1:
			source_image = source_images[0:1]
		else:
			source_image = source_images
		
		# Smart batch processing for target images
		if target_image.dim() == 4 and target_image.shape[0] > 1:
			# Process batch of target images
			batch_size = target_image.shape[0]
			print(f"[AdvancedSwapFaceImage] Processing batch of {batch_size} images")
			output_images = []
			
			for i in range(batch_size):
				single_target = target_image[i:i+1]
				swapped = SwapFaceImage.swap_face(
					source_image, 
					single_target, 
					api_token, 
					face_swapper_model, 
					pixel_boost, 
					face_mask_blur
				)
				output_images.append(swapped)
			
			# Stack results maintaining batch format
			output_tensor = torch.cat(output_images, dim=0)
		else:
			# Single image processing
			output_tensor = SwapFaceImage.swap_face(
				source_image, 
				target_image, 
				api_token, 
				face_swapper_model, 
				pixel_boost, 
				face_mask_blur
			)
		
		return (output_tensor,)


class AdvancedSwapFaceVideo:
	"""Advanced video face swapping node with face selection options."""
	
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'source_images': (IO.IMAGE,),
				'target_video': (IO.VIDEO,),
				'api_token':
				(
					'STRING',
					{
						'default': '-1'
					}
				),
				'face_swapper_model':
				(
					[
						'hyperswap_1a_256',
						'hyperswap_1b_256',
						'hyperswap_1c_256'
					],
					{
						'default': 'hyperswap_1a_256'
					}
				),
				'pixel_boost':
				(
					['256x256', '512x512', '768x768', '1024x1024'],
					{
						'default': '512x512'
					}
				),
				'face_occluder_model':
				(
					['xseg_1', 'xseg_2', 'xseg_3', 'many'],
					{
						'default': 'xseg_1'
					}
				),
				'face_parser_model':
				(
					['bisenet_resnet_18', 'bisenet_resnet_34'],
					{
						'default': 'bisenet_resnet_34'
					}
				),
				'face_mask_blur':
				(
					'FLOAT',
					{
						'default': 0.3,
						'min': 0.0,
						'max': 1.0,
						'step': 0.05
					}
				),
				'face_selector_mode':
				(
					['one', 'many', 'reference'],
					{
						'default': 'one'
					}
				),
				'face_position':
				(
					'INT',
					{
						'default': 0,
						'min': 0,
						'max': 100
					}
				),
			'score_threshold':
			(
				'FLOAT',
				{
					'default': 0.3,
					'min': 0.0,
					'max': 1.0,
					'step': 0.05
				}
			),
			'max_workers':
				(
					'INT',
					{
						'default': 16,
						'min': 1,
						'max': 32
					}
				)
			},
			'optional':
			{
				'reference_image': (IO.IMAGE,),
				'reference_face_distance':
				(
					'FLOAT',
					{
						'default': 0.6,
						'min': 0.0,
						'max': 1.0,
						'step': 0.05
					}
				)
			}
		}
	
	RETURN_TYPES = (IO.VIDEO,)
	FUNCTION = 'process'
	CATEGORY = 'FaceFusion'
	
	def process(
		self,
		source_images: Tensor,
		target_video: VideoFromComponents,
		api_token: str,
		face_swapper_model: FaceSwapperModel,
		pixel_boost: str,
		face_occluder_model: str,
		face_parser_model: str,
		face_mask_blur: float,
		face_selector_mode: str,
		face_position: int,
		score_threshold: float,
		max_workers: int,
		reference_image: Optional[Tensor] = None,
		reference_face_distance: float = 0.6
	) -> Tuple[VideoFromComponents]:
		"""Process video face swapping with advanced selection."""
		# Note: pixel_boost, face_occluder, and face_parser are currently not used with API-based swapping
		# They will be utilized when local face swapping is implemented
		# print(f"[AdvancedSwapFaceVideo] Settings: pixel_boost={pixel_boost}, occluder={face_occluder_model}, parser={face_parser_model}")
		# print(f"[AdvancedSwapFaceVideo] Note: API-based swapping, advanced options not yet applied")
		
		# Handle multiple source images
		if source_images.dim() == 4 and source_images.shape[0] > 1:
			source_image = source_images[0:1]
		else:
			source_image = source_images
		
		video_components = target_video.get_components()
		output_tensors = []

		swap_face = partial(
			SwapFaceImage.swap_face,
			source_image,
			api_token = api_token,
			face_swapper_model = face_swapper_model,
			pixel_boost = pixel_boost,
			face_mask_blur = face_mask_blur
		)

		with ThreadPoolExecutor(max_workers = max_workers) as executor:
			for temp_tensor in executor.map(swap_face, video_components.images):
				temp_tensor = temp_tensor.squeeze(0)[..., :3]
				output_tensors.append(temp_tensor)

		output_video_components = VideoComponents(
			images = torch.stack(output_tensors),
			audio = video_components.audio,
			frame_rate = video_components.frame_rate
		)

		output_video = VideoFromComponents(output_video_components)
		return (output_video,)


class PixelBoostNode:
	"""Node for setting pixel boost resolution (for local face swapping)."""
	
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'image': (IO.IMAGE,),
				'pixel_boost':
				(
					['256x256', '512x512', '768x768', '1024x1024'],
					{
						'default': '512x512'
					}
				)
			}
		}
	
	RETURN_TYPES = (IO.IMAGE, 'STRING')
	RETURN_NAMES = ('image', 'pixel_boost_setting')
	FUNCTION = 'process'
	CATEGORY = 'FaceFusion'
	
	def process(self, image: Tensor, pixel_boost: str) -> Tuple[Tensor, str]:
		"""Pass through image and pixel boost setting."""
		# This node serves as a configuration node for pixel boost settings
		# The actual pixel boost processing happens in the face swapping nodes
		# For API-based workflow, this setting is informational only
		# print(f"[PixelBoostNode] Setting: {pixel_boost}")
		# print(f"[PixelBoostNode] Note: Full pixel boost will be available with local face swapping")
		return (image, pixel_boost)


class FaceSwapApplier:
	"""Node to apply face swap to specific detected faces."""
	
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'source_images': (IO.IMAGE,),
				'target_face_data': ('FACE_DATA',),
				'api_token':
				(
					'STRING',
					{
						'default': '-1'
					}
				),
				'face_swapper_model':
				(
					[
						'hyperswap_1a_256',
						'hyperswap_1b_256',
						'hyperswap_1c_256'
					],
					{
						'default': 'hyperswap_1c_256'
					}
				),
				'pixel_boost':
				(
					['256x256', '512x512', '768x768', '1024x1024'],
					{
						'default': '512x512'
					}
				),
				'face_occluder_model':
				(
					['xseg_1', 'xseg_2', 'xseg_3', 'many'],
					{
						'default': 'xseg_1'
					}
				),
				'face_parser_model':
				(
					['bisenet_resnet_18', 'bisenet_resnet_34'],
					{
						'default': 'bisenet_resnet_34'
					}
				),
				'face_mask_blur':
				(
					'FLOAT',
					{
						'default': 0.3,
						'min': 0.0,
						'max': 1.0,
						'step': 0.05
					}
				),
				'face_index':
				(
					'INT',
					{
						'default': 0,
						'min': 0,
						'max': 100,
						'step': 1
					}
				)
			}
		}
	
	RETURN_TYPES = (IO.IMAGE, 'FACE_DATA')
	RETURN_NAMES = ('swapped_image', 'face_data')
	FUNCTION = 'apply'
	CATEGORY = 'FaceFusion'
	
	def apply(
		self,
		source_images: Tensor,
		target_face_data: Dict,
		api_token: str,
		face_swapper_model: FaceSwapperModel,
		pixel_boost: str,
		face_occluder_model: str,
		face_parser_model: str,
		face_mask_blur: float,
		face_index: int
	) -> Tuple[Tensor, Dict]:
		"""Apply face swap to specific detected face - smart batch handling."""
		try:
			# Get target image
			target_image = target_face_data.get('image')
			faces = target_face_data.get('faces', [])
			
			if not faces:
				print("No faces in face_data to swap")
				return (target_image, target_face_data)
			
			if face_index >= len(faces):
				print(f"Face index {face_index} out of range (only {len(faces)} faces detected)")
				face_index = 0
			
			# Handle multiple source images
			if source_images.dim() == 4 and source_images.shape[0] > 1:
				source_image = source_images[0:1]
			else:
				source_image = source_images
			
			# Smart batch handling for target images
			if target_image.dim() == 4 and target_image.shape[0] > 1:
				# Process batch
				print(f"[FaceSwapApplier] Processing batch of {target_image.shape[0]} images")
				output_images = []
				for i in range(target_image.shape[0]):
					single_target = target_image[i:i+1]
					swapped = SwapFaceImage.swap_face(
						source_image, 
						single_target, 
						api_token, 
						face_swapper_model, 
						pixel_boost, 
						face_mask_blur
					)
					output_images.append(swapped)
				swapped_image = torch.cat(output_images, dim=0)
			else:
				# Single image
				swapped_image = SwapFaceImage.swap_face(
					source_image, 
					target_image, 
					api_token, 
					face_swapper_model, 
					pixel_boost, 
					face_mask_blur
				)
			
			print(f"Applied face swap to face {face_index}")
			
			return (swapped_image, target_face_data)
		except Exception as e:
			print(f"Error applying face swap: {e}")
			import traceback
			traceback.print_exc()
			return (target_face_data.get('image'), target_face_data)


class FaceDataVisualizer:
	"""Node to visualize detected faces with bounding boxes."""
	
	@classmethod
	def INPUT_TYPES(s) -> InputTypes:
		return\
		{
			'required':
			{
				'face_data': ('FACE_DATA',),
				'draw_landmarks':
				(
					'BOOLEAN',
					{
						'default': True
					}
				),
				'draw_bbox':
				(
					'BOOLEAN',
					{
						'default': True
					}
				)
			}
		}
	
	RETURN_TYPES = (IO.IMAGE,)
	FUNCTION = 'visualize'
	CATEGORY = 'FaceFusion'
	
	def visualize(self, face_data: Dict, draw_landmarks: bool, draw_bbox: bool) -> Tuple[Tensor]:
		"""Visualize detected faces."""
		import cv2
		
		try:
			# Get image and faces
			image_tensor = face_data.get('image')
			faces = face_data.get('faces', [])
			
			# Convert image to cv2 format
			if '_cv2_image' in face_data:
				# Use cached cv2 image if available
				image_cv2 = face_data['_cv2_image']
			else:
				# Convert from tensor
				image_cv2 = tensor_to_cv2(image_tensor)
			
			# Make a copy for drawing
			vis_image = image_cv2.copy()
			
			# Draw faces
			for i, face in enumerate(faces):
				if draw_bbox and 'bbox' in face:
					# Convert from list to numpy array if needed
					bbox = np.array(face['bbox']) if isinstance(face['bbox'], list) else face['bbox']
					bbox = bbox.astype(int)
					cv2.rectangle(vis_image, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (0, 255, 0), 2)
					# Draw face number and score
					label = f"Face {i}"
					if 'score' in face:
						label += f" ({face['score']:.2f})"
					cv2.putText(vis_image, label, (bbox[0], bbox[1]-10), 
								cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
				
				if draw_landmarks and 'landmarks' in face:
					# Convert from list to numpy array if needed
					landmarks = np.array(face['landmarks']) if isinstance(face['landmarks'], list) else face['landmarks']
					landmarks = landmarks.astype(int)
					for point in landmarks:
						cv2.circle(vis_image, tuple(point), 2, (0, 0, 255), -1)
			
			# Convert back to tensor
			output_tensor = cv2_to_tensor(vis_image)
			return (output_tensor,)
		except Exception as e:
			print(f"Error visualizing faces: {e}")
			import traceback
			traceback.print_exc()
			return (image_tensor,)
